/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "stdio.h"
#include "esWiFi_app.h"

#define LOW             (0u)
#define HIGH            (1u)
#define CHANNEL_1       (0u)
#define CHANNEL_2       (1u)
#define CHANNEL_3       (2u)
#define CHANNEL_4       (3u)
#define CHANNEL_5       (4u)
#define CHANNEL_6       (5u)
#define NO_OF_CHANNELS  (6u)

//CY_ISR(Rx_interrupt) {
//    
    /* Receive Data from eS-WiFi Module */
//    esWiFiRxData.esWifiRxBuffer[esWiFiRxData.tail++] = UART_ESWIFI_GetChar();
    
    /* check for eS-Wifi RX buffer wrap */
//    if (esWiFiRxData.tail >=  ESWIFI_UART_RX_BUFFSIZE) {
        /* eS-WiFi RX buffer wrap so, reset buffer pointer to top of buffer */
//        esWiFiRxData.tail = 0;
//    }
    
    // Clear Interrupt flag
//    UART_ESWIFI_ReadRxStatus();
//}

uint8   switch_Flag=1;
/* **** Start of Switch Interrupt Service Routines **** */

uint8 enter_sw_count; /* # of filtered transitions of input pin 'SW' */
CY_ISR(Sw_Enter_Handler)
{
/* No need to clear any interrupt source */
 enter_sw_count++;
 switch_Flag=1;  
 } /* end of EnterInt_ISR() */   
    
uint8 up_sw_count; /* # of filtered transitions of input pin 'SW' */
CY_ISR(Sw_Up_Handler)
{
/* No need to clear any interrupt source */
  up_sw_count++;
  switch_Flag=1;  
} /* end of UpInt_ISR() */

uint8 down_sw_count; /* # of filtered transitions of input pin 'SW' */
CY_ISR(Sw_Down_Handler)
{
 /* No need to clear any interrupt source */
  down_sw_count++;
  switch_Flag=1;
} /* end of DownInt_ISR() */

uint8 left_sw_count; /* # of filtered transitions of input pin 'SW' */
CY_ISR(Sw_Left_Handler)
{
/* No need to clear any interrupt source */
  left_sw_count++;
  switch_Flag=1;
} /* end of LeftInt_ISR() */

uint8 right_sw_count; /* # of filtered transitions of input pin 'SW' */
CY_ISR(Sw_Right_Handler)
{
/* No need to clear any interrupt source */
  right_sw_count++;
  switch_Flag=1;
} /* end of RightInt_ISR() */

uint16 ch1_second_count;
uint8 ch1_minute_flag;

CY_ISR(Ch1_Off_Timer_Handler)/* # seconds Light is  Off */
{
    ch1_second_count++;
     
    if(ch1_second_count == 60)
    { 
        ch1_minute_flag=1;
        ch1_second_count = 0; // reset after 1 Minuite 
    }
}

uint16  ch2_second_count;
uint8   ch2_minute_flag;

CY_ISR(Ch2_Off_Timer_Handler)/* # seconds Light is  Off */
{
    ch2_second_count++;
     
    if(ch2_second_count == 60)
    { 
        ch2_minute_flag=1;
        ch2_second_count = 0; // reset after 1 Minuite 
    }
}

/* **** End of Switch Interrupt service routines **** */

void    GetSwitchs ();
void    Get_Color_Channel ();
void    Ch1_Off ();
void    Ch2_Off ();
void    Set_Color_Ch1 ();
void    Set_Color_Ch2 ();
void    Set_Steps_Ch1 ();
void    Set_Steps_Ch2 ();
void    Toggle_PRT2 ();
void    Set_Color_Ch1_Ch2 ();
void    Ch1_Ch2_Off ();
void    Set_Steps_Ch1_Ch2 ();

uint32 old, temp, new;
int     count =0;
int     off_Flag_Ch1=1;
int     off_Flag_Ch2=1;
int     ch1_Color=0;
int     ch2_Color=0;
int     ch1_Last_Color=0;
int     ch2_Last_Color=0;
int     ch1_Pointer=0;
int     ch2_Pointer=0;
int     ch1_Steps=0;
int     ch2_Steps=0;
int     channel =1;
int     Mfg =0;         // 0 is HaYWARD
int     skip_ch1=1;
int     skip_ch2=1;
int     ch1_Enter=0;
int     ch2_Enter=0;
int     ch1_Mfg=0;
int     ch2_Mfg=0;
int     ch1_Max=0;
int     ch2_Max=0;
int     hayWard_Max=18; // Set up as ... Mfg  0
int     penTair_Max=15; // Set up as ... Mfg  1

char* light_Mfg[2] = {"HAYWARD","PENTAIR"};


/* HAYWARD Light Table and Program Order */
char* hayWard[19] = {"  Light Off  ","Voodoo Lounge","Deep Blue Sea"," Royal Blue  ","Afternoon Sky"," Aqua  Green ","   Emerald   "," Cloud White ","  Warm Red   "
    ,"  Flamingo   ","Vivid Violet","   Sangria   ","  Twilight   "," Tranquility ","  Gemstone   ","     USA     "," Mardi Gras ","Cool Cabaret", "  Light On   "};
/* ************************************* */

/* PENTAIR Light Table and Program Order */
char* penTair[16] = {"  Light Off  ","     SAm     ","     Party      ","   Romance   ","  Caribbean  ","  American   "," California  ","    Royal    ","     Blue    "
    ,"    Green    ","     Red     ","    White    ","   Magenta   ","    Hold     ","   Recall    ","   Light On  "};
/* ************************************* */    

#undef ESWIFI_IPADDR
#define ESWIFI_IPADDR		"a1jfm8hc51b1nq.iot.us-west-2.amazonaws.com"		//Remote IP Address
#undef ESWIFI_PORT
#define ESWIFI_PORT			"8883"												//Remote Port

#define AWS_DEVICE_ID       "TestPoolControllerThing"
    
#define AWS_PBTOPIC			"$aws/things/"AWS_DEVICE_ID"/shadow/update"
#define AWS_SBTOPIC			AWS_PBTOPIC"/accepted"
#define MQTT_MODE			"2"
#define MQTT_CLIENT_ID		"ISM_IoT_032"

#define aws_json_pre 		"{\"state\":{\"reported\":"
#define aws_json_desired	"{\"state\":{\"desired\":"
#define aws_json_post 		"}}"

int main()
{
 /* Initialization code */
    LCD_Start();
    CyGlobalIntEnable;
    LCD_ClearDisplay();
    LCD_Position(0, 0); /* row, column */
    LCD_PrintString("Reflex Ctrl V:10");
    LCD_Position(1, 2); /* row, column */
    LCD_PrintString("Setup Routine");
    UART_ESWIFI_Start();
    CyDelay (2000);
    //Setup Wifi
//   esWifiTx((int8_t *)"A0\r");
//   CyDelay(30000);
    char msg[ESWIFI_MAX_MSG_SIZE];
    sprintf(msg,"C1=%s\r", ESWIFI_AP_SSID);
    esWifiTx((int8_t *)msg);
    sprintf(msg,"C2=%s\r", ESWIFI_AP_PASSWORD);
    esWifiTx((int8_t *)msg);
    esWifiTx((int8_t *)"C3=3\r");
    esWifiTx((int8_t *)"C0\r");
    CyDelay (4000);
    esWifiTx((int8_t *)"P0=0\r");
    sprintf(msg,"D0=%s\r",ESWIFI_IPADDR);
    esWifiTx((int8_t *)msg);
    esWifiTx((int8_t *)"P1=4\r");
    sprintf(msg,"P4=%s\r",ESWIFI_PORT);
    esWifiTx((int8_t *)msg);   
    sprintf(msg,"PM=0,%s\r",AWS_PBTOPIC);
    esWifiTx((int8_t *)msg);
    sprintf(msg,"PM=1,%s\r",AWS_SBTOPIC);
    esWifiTx((int8_t *)msg);
    sprintf(msg,"PM=2,%s\r",MQTT_MODE);
    esWifiTx((int8_t *)msg);
    sprintf(msg,"PM=5,%s\r",MQTT_CLIENT_ID);
    esWifiTx((int8_t *)msg);
    esWifiTx((int8_t *)"P6=1\r");
    CyDelay(4000);		//10ms delay
        
    memset(eswifi_app_buf.txData,'\0',ESWIFI_APP_BUF_SIZE+10);		//Clear App TX buffer
    memset(eswifi_app_buf.payload,'\0',ESWIFI_APP_BUF_SIZE);			//Clear App Payload buffer

		  /* create desired message */
    strcat((char *)&eswifi_app_buf.payload,aws_json_pre);
	sprintf(msg,"{\"colorIndex\":\"%d\"}",ch1_Color);
	strcat((char *)&eswifi_app_buf.payload,msg);
	strcat((char *)&eswifi_app_buf.payload,aws_json_post);

         /* Send message */
	sprintf((char *)&eswifi_app_buf.txData,"S3=%d\r%s",(int)strlen((char*)&eswifi_app_buf.payload),(char*)&eswifi_app_buf.payload);
	esWifiTx((int8_t *)eswifi_app_buf.txData);
    //Set up Manufacture of Lights
    // If HAYWARD
    if (Mfg==0)
    {
    ch1_Max=hayWard_Max;
    ch2_Max=hayWard_Max;
    ch1_Mfg=0;
    ch2_Mfg=0;
    }
    // Set up Manufacture of Lights
    // If PENTAIR
    if (Mfg==1)
    {
    ch1_Max=penTair_Max;
    ch2_Max=penTair_Max;
    ch1_Mfg=1;
    ch2_Mfg=1;
    } 
    
    //  **** Sync up Heyward Lights ****  //
    LCD_ClearDisplay();
    LCD_Position(0, 0); /* row, column */
    LCD_PrintString("  Synchronizing ");
    LCD_Position(1, 0); /* row, column */
    LCD_PrintString("  Please Wait  ");
    // Drive port2 pins 2[1]&2[3] Hi
    Toggle_PRT2(); // On                 
    // Delay 16 sec for start up turn on delay
    CyDelay (16000);                
    // Drive port2 pins 2[1]&2[3] Low
    Toggle_PRT2(); // Off
    // delay 12 seconds for setting light color reset
    CyDelay(12000);             
    // Drive port2 pins 2[1]&2[3] Hi
    Toggle_PRT2(); // On
    // delay 2 seconds
    CyDelay (2000);              
     // Drive port2 pins 2[1]&2[3] Low
    Toggle_PRT2();  // Off
    // delay 60 seconds to set light to color posistion 1 at turn on.
    CyDelay (58000);
    // Program Order in HAYWARD Light is set to point at first color
    //  **********************************  //
    
    LCD_ClearDisplay();
    LCD_Position(0, 0); /* row, column */
    LCD_PrintString("Synch Complete");
    LCD_Position(1, 0); /* row, column */
    LCD_PrintString("Ready for Colors"); 
    CyDelay (2000);              // Program Order in HAYWARD Light is set to 1
    
    ch1_Last_Color=1;            // Start up synch color is set for one on ch1
    ch2_Last_Color=1;            // Start up synch color is set for one on ch2
    ch1_Pointer=1;               // set Ch1 Light Color pointer posistion to 1
    ch2_Pointer=1;               // set Ch2 Light Color pointer posistion to 1    
    ch1_Color=0;                 // Start up with Ch1 Color 0 which is Off
    ch2_Color=0;                 // Start up with Ch2 Color 0 which is Off
    off_Flag_Ch1=1;              // start with off flag set on Ch1
    off_Flag_Ch2=1;              // start with off flag set on Ch2       
    ch1_minute_flag=1;           // start with 60 second flag set on Ch1
    ch2_minute_flag=1;           // start with 60 second flag set on Ch2
    LCD_ClearDisplay();

    // end of sync routine
    
    // set up switch interupts
    Sw_Enter_Int_StartEx(Sw_Enter_Handler);
    Sw_Up_Int_StartEx(Sw_Up_Handler);
    Sw_Down_Int_StartEx(Sw_Down_Handler);
    Sw_Left_Int_StartEx(Sw_Left_Handler);
    Sw_Right_Int_StartEx(Sw_Right_Handler);
    
    // set up Timer interrupts
    Ch1_Off_Timer_Int_StartEx(Ch1_Off_Timer_Handler);
    Ch2_Off_Timer_Int_StartEx(Ch2_Off_Timer_Handler);
    // stop interup timers
    Ch1_Off_Timer_Stop();
    Ch2_Off_Timer_Stop();
    

    
 for(;;) // do forever //  
  {        
    
    GetSwitchs ();
    Get_Color_Channel ();
    
    
  }// end of for() Forever Loop //
return 0;
}/* end of main() Routine  */



/* ************************************************ */

void Toggle_PRT2()
{
    // routine toggles state of port2 pin 2[1] and p2[3]
    old=CY_GET_REG32(CYREG_GPIO_PRT2_DR);
    temp=old;
    temp=temp ^ 0x01010000F;
    new=temp;
    CY_SET_REG32(CYREG_GPIO_PRT2_DR, new);
    return;   
}

//  ****************************************************  //

/*   Subroutine for For Setting Both Channel Colors     */
void Set_Color_Ch1_Ch2()
{    
    int i;
    for (i=2;i>1;i--)                                       // run only one time
    {

        if (ch1_Color==0)
        {    
      // check to see if Ch1 is already off
            if (off_Flag_Ch1==1)
      // Do noting if off already
            {
            LCD_ClearDisplay();    
            LCD_Position(0, 1); /* row, column */
            LCD_PrintString("No Power Change");
            CyDelay(500);
            LCD_ClearDisplay();
            break;
            } 
      // routine to turn off the light and set timers     
        Ch1_Ch2_Off ();                                        // turn off ch1
        break;
        }     
      // Check to see if color is the same                  
        if (ch1_Color == ch1_Pointer)                       
        {
            if(off_Flag_Ch1==1)                             // this routine is for if after reset
            {                                               // the selction is to go to posistion 1
            LCD_ClearDisplay();    
            ch1_Pointer=ch1_Color;
            ch2_Pointer=ch2_Color;
            LCD_Position(0, 1); /* row, column */   
            LCD_PrintString("Turn On CH1");
            LCD_Position(1, 1); /* row, column */   
            LCD_PrintString("Turn On CH2");
            CyDelay(500);               
            ch1_Steps=0;
            ch2_Steps=0;
            Set_Steps_Ch1_Ch2();
            LCD_ClearDisplay();
            break;
            }
        // Do noting if the color and pointer have not changed
        LCD_ClearDisplay();    
        LCD_Position(0, 1); /* row, column */
        LCD_PrintString("No Color Change");
        CyDelay(500);
        LCD_ClearDisplay();
        break;
        }
     // Check to see if the color is set to turn the light on from off
        if (ch1_Color==ch1_Max)
        {
        LCD_ClearDisplay();    
        LCD_Position(0, 1); /* row, column */
        LCD_PrintString("Turn on Last");
        LCD_Position(1, 1); /* row, column */
        LCD_PrintString("   Color Set   ");
        CyDelay(500);
        LCD_ClearDisplay();    
        ch1_Steps=0;
        ch2_Steps=0;
        ch1_Color=ch1_Pointer;  // make the current pointer color the current color
        ch2_Color=ch2_Pointer;
        Set_Steps_Ch1_Ch2 ();    
        }
     // Check if ch1_color is greater than current pointer posistion
        if (ch1_Color > ch1_Pointer)                   
        {                                                   // Test             >> If Color is 15 and Pointer is 4
        ch1_Steps=ch1_Color-ch1_Pointer;                    // (15-4)=11        >> Steps is set to 11 Checks
        ch1_Pointer=ch1_Color;                              //  =15             >> Pointer is set to 15 Checks
        ch2_Pointer=ch2_Color;    
        Set_Steps_Ch1_Ch2 ();                                   
        break;
        }
     // check if ch1_color is less than current pointer posistion
        if (ch1_Color < ch1_Pointer)                               
        {                                                   //  Test            >> If Color is 7 and Pointer at 15
        ch1_Steps=(ch1_Max-(ch1_Pointer-ch1_Color))-1;          //  (17-(15-7)= 9   >> Steps is set to 15 Checks
        ch1_Pointer=ch1_Color;                              //   =2             >> Pointer is set to 2 Checks
        ch2_Pointer=ch2_Color;
        Set_Steps_Ch1_Ch2 ();    
        break;
        }
    }
    return;
}

/* Subroutine for For Setting Channel One Steps*/
void Set_Steps_Ch1_Ch2 ()
{
    // routine for when turing on light when return from off time less than 60 seconds on ch1
    if (ch1_minute_flag==0 && off_Flag_Ch1==1)
        {
        LCD_ClearDisplay();
        LCD_Position(0, 0); /* row, column */
        LCD_PrintString("Delay for <1min");
        LCD_Position(1, 2); /* row, column */
        LCD_PrintString(hayWard[ch1_Color]);
        //Drv_1_Write(HIGH);
        Toggle_PRT2();              // turn both lights on
        CyDelay(17000);             // delay for 16 seconds for light to cycle white to color
        off_Flag_Ch1=0;             // clear ch1 off flag
        off_Flag_Ch2=0;
        ch1_minute_flag=0;          // clear ch1_minute_flag
        ch2_minute_flag=0;
        ch1_second_count=0;         // clear second count
        ch2_second_count=0;
        Ch1_Off_Timer_Stop();       // stop the 1 minute timer
        Ch2_Off_Timer_Stop();
        LCD_ClearDisplay();
        }
    // routine for when turing on light when return from off time greater than 60 seconds on ch1
    if (ch1_minute_flag==1)
        {
        LCD_ClearDisplay();
        LCD_Position(0, 0); /* row, column */
        LCD_PrintString("Delay for >1min");
        LCD_Position(1, 2); /* row, column */
        LCD_PrintString(hayWard[ch1_Color]);
        //Drv_1_Write(HIGH);
        Toggle_PRT2();              // turn on both lights
        CyDelay(17000);             // delay for 16 seconds for light to cycle white to color
        off_Flag_Ch1=0;             // clear ch1 off flag
        off_Flag_Ch2=0;
        ch1_minute_flag=0;          // clear ch1_minute_flag
        ch2_minute_flag=0;
        ch1_second_count=0;         // clear second count
        ch2_second_count=0;
        Ch1_Off_Timer_Stop();       // stop the 1 minute timer
        Ch2_Off_Timer_Stop();
        LCD_ClearDisplay();
        }
    // routine for when light is already on and color has not changed on ch1
    if(ch1_Steps==0)
        {
        off_Flag_Ch1=0;             // clear ch1 off flag
        off_Flag_Ch2=0;    
        ch1_minute_flag=0;          // clear ch1_minute_flag
        ch2_minute_flag=0;    
        ch1_second_count=0;         // clear second count
        ch2_second_count=0;    
        Ch1_Off_Timer_Stop();       // stop the 1 minute timer
        Ch2_Off_Timer_Stop();
        return;
        }
        
    // *******************************************
        count=ch1_Steps;
        while (count >0)              //
        {
        LCD_ClearDisplay();
        LCD_Position(0, 0); /* row, column */
        LCD_PrintString("SETTING Both TO");
        LCD_Position(1, 2); /* row, column */
        LCD_PrintString(hayWard[ch1_Color]);
        Toggle_PRT2();          // low
        CyDelay(500);
        Toggle_PRT2();          // Hi
        CyDelay(500);
        count--;
        }
        off_Flag_Ch1=0;                     // clear ch1 off flag
        off_Flag_Ch2=0;
        LCD_ClearDisplay();
    return;
}

/* Subroutine for Turning Off Channel One */
void Ch1_Ch2_Off ()
{
    // routine to turn off the light and when it has been on , also resets timers
    Toggle_PRT2();                                      // Turn off both channels
    off_Flag_Ch1=1;                                    // set off flag
    off_Flag_Ch2=1;
    ch1_minute_flag=0;                                 // set up memory for 60 second timer
    ch2_minute_flag=0;
    ch1_second_count=0;
    ch2_second_count=0;
    Ch1_Off_Timer_Start();                             // start off 60 second timer
    Ch2_Off_Timer_Start();
    skip_ch1=1;
    skip_ch2=1;
    LCD_ClearDisplay();
    LCD_Position(0, 0); /* row, column */
    LCD_PrintString("TURN OFF ");
    LCD_Position(1, 0); /* row, column */
    LCD_PrintString(" Both Channels ");
    CyDelay (2000);
    LCD_ClearDisplay();
    LCD_Position(0, 0); /* row, column */
    LCD_PrintString("Please Wait ");
    LCD_Position(1, 0); /* row, column */
    LCD_PrintString("Saving Settings");
    CyDelay (16000);
    LCD_ClearDisplay();
    return;
}

//  ****************************************************  //

/*   Subroutine for For Setting Channel One Color     */
void Set_Color_Ch1 ()
{    
    int i;
    for (i=2;i>1;i--)                                       // run only one time
    {

        if (ch1_Color==0)
        {    
      // check to see if Ch1 is already off
            if (off_Flag_Ch1==1)
      // Do noting if off already
            {
            LCD_ClearDisplay();    
            LCD_Position(0, 1); /* row, column */
            LCD_PrintString("No Color Change");
            CyDelay(500);
            LCD_ClearDisplay();
            break;
            } 
      // routine to turn off the light and set timers     
        Ch1_Off ();                                        // turn off ch1
        break;
        }     
      // Check to see if color is the same                  // test Point is 15 color is 7
        if (ch1_Color == ch1_Pointer)                       
        {
            if(off_Flag_Ch1==1)                             // this routine is for if after reset
            {                                               // the selction is to go to posistion 1
            LCD_ClearDisplay();    
            ch1_Pointer=ch1_Color;
            LCD_Position(0, 1); /* row, column */   
            LCD_PrintString("Turn On CH1");
            CyDelay(500);               
            ch1_Steps=0;
            Set_Steps_Ch1();
            LCD_ClearDisplay();
            break;
            }
        // Do noting if the color and pointer have not changed
        LCD_ClearDisplay();    
        LCD_Position(0, 1); /* row, column */
        LCD_PrintString("No Color Change");
        CyDelay(500);
        LCD_ClearDisplay();
        break;
        }
     // Check to see if the color is set to turn the light on from off
        if (ch1_Color==ch1_Max)
        {
        LCD_ClearDisplay();    
        LCD_Position(0, 1); /* row, column */
        LCD_PrintString("Turn on Last");
        LCD_Position(1, 1); /* row, column */
        LCD_PrintString("   Color Set   ");
        CyDelay(500);
        LCD_ClearDisplay();    
        ch1_Steps=0;
        ch1_Color=ch1_Pointer;  // make the current pointer color the current color    
        Set_Steps_Ch1 ();    
        }
     // Check if ch1_color is greater than current pointer posistion
        if (ch1_Color > ch1_Pointer)                   
        {                                                   // Test             >> If Color is 15 and Pointer is 4
        ch1_Steps=ch1_Color-ch1_Pointer;                    // (15-4)=11        >> Steps is set to 11 Checks
        ch1_Pointer=ch1_Color;                              //  =15             >> Pointer is set to 15 Checks   
        Set_Steps_Ch1 ();                                   
        break;
        }
     // check if ch1_color is less than current pointer posistion
        if (ch1_Color < ch1_Pointer)                               
        {                                                   //  Test            >> If Color is 7 and Pointer at 15
        ch1_Steps=(ch1_Max-(ch1_Pointer-ch1_Color))-1;          //  (17-(15-7)= 9   >> Steps is set to 15 Checks
        ch1_Pointer=ch1_Color;                              //   =2             >> Pointer is set to 2 Checks
        Set_Steps_Ch1 ();    
        break;
        }
    }
    return;
}

/* Subroutine for For Setting Channel One Steps*/
void Set_Steps_Ch1 ()
{
    // routine for when turing on light when return from off time less than 60 seconds on ch1
    if (ch1_minute_flag==0 && off_Flag_Ch1==1)
        {
        LCD_ClearDisplay();
        LCD_Position(0, 0); /* row, column */
        LCD_PrintString("Delay for <1min");
        LCD_Position(1, 2); /* row, column */
        LCD_PrintString(hayWard[ch1_Color]);
        Drv_1_Write(HIGH);
        CyDelay(17000);             // delay for 16 seconds for light to cycle white to color
        off_Flag_Ch1=0;             // clear ch1 off flag
        ch1_minute_flag=0;          // clear ch1_minute_flag
        ch1_second_count=0;         // clear second count
        Ch1_Off_Timer_Stop();       // stop the 1 minute timer
        LCD_ClearDisplay();
        }
    // routine for when turing on light when return from off time greater than 60 seconds on ch1
    if (ch1_minute_flag==1)
        {
        LCD_ClearDisplay();
        LCD_Position(0, 0); /* row, column */
        LCD_PrintString("Delay for >1min");
        LCD_Position(1, 2); /* row, column */
        LCD_PrintString(hayWard[ch1_Color]);
        Drv_1_Write(HIGH);
        CyDelay(17000);             // delay for 16 seconds for light to cycle white to color
        off_Flag_Ch1=0;             // clear ch1 off flag
        ch1_minute_flag=0;          // clear ch1_minute_flag
        ch1_second_count=0;         // clear second count
        Ch1_Off_Timer_Stop();       // stop the 1 minute timer
        LCD_ClearDisplay();
        }
    // routine for when light is already on and color has not changed on ch1
    if(ch1_Steps==0)
        {
        off_Flag_Ch1=0;             // clear ch1 off flag
        ch1_minute_flag=0;          // clear ch1_minute_flag
        ch1_second_count=0;         // clear second count
        Ch1_Off_Timer_Stop();       // stop the 1 minute timer
        return;
        }
        
    // *******************************************
        count=ch1_Steps;
        while (count >0)              //
        {
        LCD_ClearDisplay();
        LCD_Position(0, 0); /* row, column */
        LCD_PrintString("SETTING CH1 TO");
        LCD_Position(1, 2); /* row, column */
        LCD_PrintString(hayWard[ch1_Color]);
        Drv_1_Write(LOW);
        CyDelay(500);
        Drv_1_Write(HIGH);
        CyDelay(500);
        count--;
        }
        off_Flag_Ch1=0;                     // clear ch1 off flag
        LCD_ClearDisplay();
    return;
}

/* Subroutine for Turning Off Channel One */
void Ch1_Off ()
{
    Drv_1_Write(LOW);   // Turn Ch1 off
    // routine to turn off the light and when it has been on , also resets timers
    off_Flag_Ch1=1;                                    // set off flag    
    ch1_minute_flag=0;                                 // set up memory for 60 second timer
    ch1_second_count=0;                     
    Ch1_Off_Timer_Start();                             // start off 60 second timer
    skip_ch1=1;
    LCD_ClearDisplay();
    LCD_Position(0, 0); /* row, column */
    LCD_PrintString("TURN OFF ");
    LCD_Position(1, 0); /* row, column */
    LCD_PrintString("Channel One");
    CyDelay (1000);
    LCD_ClearDisplay();
    LCD_Position(0, 0); /* row, column */
    LCD_PrintString("Please Wait ");
    LCD_Position(1, 0); /* row, column */
    LCD_PrintString("Saving Settings");
    CyDelay (16000);
    LCD_ClearDisplay();
    return;
}

/*   Subroutine for For Setting Channel Two Color     */
void Set_Color_Ch2 ()
{    
    int i;
    for (i=2;i>1;i--)                                       // run only one time
    {
        if (ch2_Color==0)
        {    
      // check to see if Ch2 is already off
            if (off_Flag_Ch2==1)
      // Do noting if off already
            {
            LCD_ClearDisplay();    
            LCD_Position(1, 1); /* row, column */
            LCD_PrintString("No Power Change");
            CyDelay(500);
            LCD_ClearDisplay();
            break;
            } 
      // routine to turn off the light and turn on 1 minute timer     
        Ch2_Off ();                                        // turn off ch2
        break;
        }     
      // Check to see if color is the same                  // test Point is 15 color is 7
        if (ch2_Color == ch2_Pointer)                       
        {
            if(off_Flag_Ch2==1)                             // this routine is for if after reset
            {                                               // the selction is to go to posistion 1
            LCD_ClearDisplay();
            ch2_Pointer=ch2_Color;
            LCD_Position(1, 1); /* row, column */   
            LCD_PrintString("Turn On CH2");
            CyDelay(500);               
            ch2_Steps=0;
            Set_Steps_Ch2();
            LCD_ClearDisplay();
            break;
            }
        // Do noting if the color and pointer have not changed
        LCD_ClearDisplay();    
        LCD_Position(1, 1); /* row, column */
        LCD_PrintString("No Color Change");
        CyDelay(500);
        LCD_ClearDisplay();
        break;
        }
     // Check to see if the color is set to turn the light on from off
        if (ch2_Color==ch2_Max)
        {
        LCD_ClearDisplay();    
        LCD_Position(0, 1); /* row, column */
        LCD_PrintString("Turn on Last");
        LCD_Position(1, 1); /* row, column */
        LCD_PrintString("   Color Set   ");
        CyDelay(500);
        LCD_ClearDisplay();    
        ch2_Steps=0;
        ch2_Color=ch2_Pointer;  // make the current pointer color the current color    
        Set_Steps_Ch2 ();    
        }
     // Check if ch1_color is greater than current pointer posistion
        if (ch2_Color > ch2_Pointer)                   
        {                                                   // Test             >> If Color is 15 and Pointer is 4
        ch2_Steps=ch2_Color-ch2_Pointer;                    // (15-4)=11        >> Steps is set to 11 Checks
        ch2_Pointer=ch2_Color;                              //  =15             >> Pointer is set to 15 Checks
        Set_Steps_Ch2 ();                                   
        break;
        }
     // check if ch1_color is less than current pointer posistion
        if (ch2_Color < ch2_Pointer)                               
        {                                                   //  Test            >> If Color is 2 and Pointer at 4
        ch2_Steps=(ch2_Max-(ch2_Pointer-ch2_Color))-1;          //  (17-(4-2)= 15   >> Steps is set to 15 Checks
        ch2_Pointer=ch2_Color;                              //   =2             >> Pointer is set to 2 Checks 
        Set_Steps_Ch2 ();    
        break;
        }
    }
    return;
}

/* Subroutine for For Setting Channel Two Steps*/
void Set_Steps_Ch2 ()
{
    // routine for when turing on light when return from off time less than 60 seconds on ch2
    if (ch2_minute_flag==0 && off_Flag_Ch2==1)
    {
        LCD_ClearDisplay();
        LCD_Position(0, 0); /* row, column */
        LCD_PrintString("Delay for <1min");
        LCD_Position(1, 2); /* row, column */
        LCD_PrintString(hayWard[ch2_Color]);
        Drv_2_Write(HIGH);
        CyDelay(17000);             // delay for 16 seconds for light to cycle white to color
        off_Flag_Ch2=0;             // clear ch1 off flag
        ch2_minute_flag=0;          // clear ch1_minute_flag
        ch2_second_count=0;         // clear second count
        Ch2_Off_Timer_Stop();       // stop the 1 minute timer
        LCD_ClearDisplay();
    }
    // routine for when turing on light when return from off time greater than 60 seconds on ch2
    if (ch2_minute_flag==1)
        {
        LCD_ClearDisplay();
        LCD_Position(0, 0); /* row, column */
        LCD_PrintString("Delay for >1min");
        LCD_Position(1, 2); /* row, column */
        LCD_PrintString(hayWard[ch2_Color]);
        Drv_2_Write(HIGH);
        CyDelay(17000);             // delay for 16 seconds for light to cycle white to color
        off_Flag_Ch2=0;             // clear ch2 off flag
        ch2_minute_flag=0;          // clear ch1_minute_flag
        ch2_second_count=0;         // clear second count
        Ch2_Off_Timer_Stop();       // stop the 1 minute timer
        LCD_ClearDisplay();
        }
    // routine for when light is already on and color has not changed ch2
    if(ch2_Steps==0)
        {
        off_Flag_Ch2=0;                     // clear off flag
        return;
        }
    // *******************************************
        count=ch2_Steps;
        while (count >0)              //
        {
        LCD_ClearDisplay();
        LCD_Position(0, 0); /* row, column */
        LCD_PrintString("SETTING CH2 TO");
        LCD_Position(1, 2); /* row, column */
        LCD_PrintString(hayWard[ch2_Color]);
        Drv_2_Write(LOW);
        CyDelay(500);
        Drv_2_Write(HIGH);
        CyDelay(500);
        count--;
        }
        off_Flag_Ch2=0;                     // clear ch2 off flag
        LCD_ClearDisplay();
        
    return;
}

/* Subroutine for Turning off Channel Two */
void Ch2_Off ()
{
    Drv_2_Write(LOW);   // Turn Ch2 off
    off_Flag_Ch2=1;                                    // set off flag    
    ch2_minute_flag=0;                                 // set up memory for 60 second timer
    ch2_second_count=0;                     
    Ch2_Off_Timer_Start();                             // start off 60 second timer
    LCD_ClearDisplay();
    LCD_Position(0, 0); /* row, column */
    LCD_PrintString("TURN OFF ");
    LCD_Position(1, 0); /* row, column */
    LCD_PrintString("Channel Two");
    CyDelay (1000);
    LCD_ClearDisplay();
    LCD_Position(0, 0); /* row, column */
    LCD_PrintString("Please Wait ");
    LCD_Position(1, 0); /* row, column */
    LCD_PrintString("Saving Settings");
    CyDelay (16000);
    skip_ch2=1;
    LCD_ClearDisplay();
    return;
}

/* Subroutine for getting Channel/Color/MFG  and loading channel with color*/
void Get_Color_Channel ()
{
    if (switch_Flag==1) /* detect if switch has been pressed */ 
    {
        /* Look for Enter Button to be Pressed and act on it */
        if (ch1_Enter==1 || ch2_Enter==1)
        {
            // deactivate all switch press
            Sw_Enter_Int_Stop();
            Sw_Up_Int_Stop();
            Sw_Down_Int_Stop();
            Sw_Left_Int_Stop();
            Sw_Right_Int_Stop();  
         //
        int j;
        for (j=2;j>1;j--)         // run one time
        {
         // If color selection are the same run Set both channels at the same time
            if(ch1_Color==ch2_Color && ch1_Pointer==ch2_Pointer && off_Flag_Ch1==off_Flag_Ch2)
            {
            LCD_ClearDisplay();
            LCD_Position(0, 0); // row, column //
            LCD_PrintString("Setting Both ");
            LCD_Position(1, 0); // row, column //
            LCD_PrintString("Color Channels");
            CyDelay(2000);
            LCD_ClearDisplay();
            Set_Color_Ch1_Ch2();
            ch1_Enter=0;
            ch2_Enter=0;
            // reactivate switches
            up_sw_count=0;
            down_sw_count=0;
            left_sw_count=0;
            right_sw_count=0;
            enter_sw_count=0;
            switch_Flag=0;
            Sw_Enter_Int_StartEx(Sw_Enter_Handler);
            Sw_Up_Int_StartEx(Sw_Up_Handler);
            Sw_Down_Int_StartEx(Sw_Down_Handler);
            Sw_Left_Int_StartEx(Sw_Left_Handler);
            Sw_Right_Int_StartEx(Sw_Right_Handler);
            break;
            }
            //
         // Set the color on ch1 & Ch2 outputs
            Set_Color_Ch1();
         //Clear flag for enter button press
            ch1_Enter=0;
         // delay a bit before next channel load
            CyDelay (150);
            Set_Color_Ch2();
         //Clear flag for enter button press   
            ch2_Enter=0;
            // reactivate switchs
            up_sw_count=0;
            down_sw_count=0;
            left_sw_count=0;
            right_sw_count=0;
            enter_sw_count=0;
            switch_Flag=0;
            Sw_Enter_Int_StartEx(Sw_Enter_Handler);
            Sw_Up_Int_StartEx(Sw_Up_Handler);
            Sw_Down_Int_StartEx(Sw_Down_Handler);
            Sw_Left_Int_StartEx(Sw_Left_Handler);
            Sw_Right_Int_StartEx(Sw_Right_Handler);
            break;
        }
       }
     //
        
        if (ch1_Mfg==0)             // Scroll display for ch1_Mfg==0
        {   ch1_Max=hayWard_Max;
            if (ch1_Color> ch1_Max){ch1_Color=0;}
            if (ch1_Color<0) {ch1_Color=ch1_Max;}
            LCD_Position(0, 2); /* row, column */
            LCD_PrintString(hayWard[ch1_Color]);

        }
        if (ch2_Mfg==0)             // Scroll display for ch2_Mfg==0        
        {   ch2_Max=hayWard_Max;
            if (ch2_Color> ch2_Max){ch2_Color=0;}
            if (ch2_Color<0) {ch2_Color=ch2_Max;}
            LCD_Position(1, 2); /* row, column */
            LCD_PrintString(hayWard[ch2_Color]);
         
        }
        
        if (ch1_Mfg==1)             // Scroll display for ch1_Mfg==1     
        {   ch1_Max=penTair_Max;
            if (ch1_Color> ch1_Max){ch1_Color=0;}
            if (ch1_Color<0) {ch1_Color=ch1_Max;}
        LCD_Position(0, 2); /* row, column */
        LCD_PrintString(penTair[ch1_Color]);
        }
        if (ch2_Mfg==1)             // Scroll display for ch2_Mfg==1    
        {   ch2_Max=penTair_Max;
            if (ch2_Color> ch2_Max){ch2_Color=0;}
            if (ch2_Color<0) {ch2_Color=ch2_Max;}
        LCD_Position(1, 2); /* row, column */
        LCD_PrintString(penTair[ch2_Color]);
        }

        switch_Flag=0;  /* clear switch press detection */
    }
        if (switch_Flag==0)
        {
        LCD_Position(channel-1,0); /* row, column */
        LCD_WriteControl(LCD_CURSOR_BLINK);
        CyDelay (10);
        }
    // Return from soubroutine 
    return;
}
    
/* Subroutine for getting switch presses */
 void GetSwitchs ()
{    
    /*  LCD SETUP */
    LCD_Position(0, 0); /* row, column */
    LCD_PutChar(LCD_CUSTOM_5); // Place Ch1 Character
    LCD_Position(1, 0); /* row, column */
    LCD_PutChar(LCD_CUSTOM_6); // Place Ch2 Character
    
    /******** Switch Handlers *********/

    /* Enter Switch Handler */
    if (enter_sw_count == 1)            // Switch Press 
    {  
    //LCD_Position(channel-1, 0);         /*  Set cursor posiston for placing enter symbol  */
    //LCD_PutChar(LCD_CUSTOM_4);          // enter character
    }
    if (enter_sw_count == 2)            // Switch Press Release
    {
        enter_sw_count=0;               // Switch Press Complete   
        
        if (channel==1){ch1_Enter=1;}   // Set Flag to Service Enter button Press for channel 1
        if (channel==2){ch2_Enter=1;}   // Set Flag to Service Enter button Press for channel 2
    }
    
    /* UP Switch Handler */   
    if (up_sw_count == 1)
    {
    //LCD_Position(0, 0); /* row, column */
    //LCD_PutChar(LCD_CUSTOM_0); // up character
    }
    if (up_sw_count == 2)
    {
    up_sw_count=0;
    channel = 1; // Set channel to number 1
    }
    
    /* Down Switch Handler */
    if (down_sw_count == 1)
    {
    //LCD_Position(1, 0); /* row, column */
    //LCD_PutChar(LCD_CUSTOM_1); // down character
    }
    if (down_sw_count == 2)
    {
    down_sw_count=0;   
    channel = 2; // Set channel to number 2  
    }
    
    /* Left Switch Handler */   
    if (left_sw_count == 1)
    {
    //LCD_Position(channel-1, 0); /* row, column */
    //LCD_PutChar(LCD_CUSTOM_3); // enter character
    }
    if (left_sw_count == 2)
    {
    left_sw_count=0;
   
        if (channel==1)
        {
        ch1_Color--;
        }
        if (channel==2)
        {
        ch2_Color--;
        }        
    }
    
    /* Right Switch Handler */
    if (right_sw_count == 1)
    {
    //LCD_Position(channel-1, 0); /* row, column */
    //LCD_PutChar(LCD_CUSTOM_2); // enter character
    }
    if (right_sw_count == 2)
    {
    right_sw_count=0;
        
        if (channel==1)
        {
        ch1_Color++;
        }
        if (channel==2)
        {
        ch2_Color++;
        }
    }
    return;
 }
