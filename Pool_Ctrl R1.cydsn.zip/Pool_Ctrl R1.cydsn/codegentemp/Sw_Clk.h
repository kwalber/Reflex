/*******************************************************************************
* File Name: Sw_Clk.h
* Version 2.20
*
*  Description:
*   Provides the function and constant definitions for the clock component.
*
*  Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CLOCK_Sw_Clk_H)
#define CY_CLOCK_Sw_Clk_H

#include <cytypes.h>
#include <cyfitter.h>


/***************************************
*        Function Prototypes
***************************************/
#if defined CYREG_PERI_DIV_CMD

void Sw_Clk_StartEx(uint32 alignClkDiv);
#define Sw_Clk_Start() \
    Sw_Clk_StartEx(Sw_Clk__PA_DIV_ID)

#else

void Sw_Clk_Start(void);

#endif/* CYREG_PERI_DIV_CMD */

void Sw_Clk_Stop(void);

void Sw_Clk_SetFractionalDividerRegister(uint16 clkDivider, uint8 clkFractional);

uint16 Sw_Clk_GetDividerRegister(void);
uint8  Sw_Clk_GetFractionalDividerRegister(void);

#define Sw_Clk_Enable()                         Sw_Clk_Start()
#define Sw_Clk_Disable()                        Sw_Clk_Stop()
#define Sw_Clk_SetDividerRegister(clkDivider, reset)  \
    Sw_Clk_SetFractionalDividerRegister((clkDivider), 0u)
#define Sw_Clk_SetDivider(clkDivider)           Sw_Clk_SetDividerRegister((clkDivider), 1u)
#define Sw_Clk_SetDividerValue(clkDivider)      Sw_Clk_SetDividerRegister((clkDivider) - 1u, 1u)


/***************************************
*             Registers
***************************************/
#if defined CYREG_PERI_DIV_CMD

#define Sw_Clk_DIV_ID     Sw_Clk__DIV_ID

#define Sw_Clk_CMD_REG    (*(reg32 *)CYREG_PERI_DIV_CMD)
#define Sw_Clk_CTRL_REG   (*(reg32 *)Sw_Clk__CTRL_REGISTER)
#define Sw_Clk_DIV_REG    (*(reg32 *)Sw_Clk__DIV_REGISTER)

#define Sw_Clk_CMD_DIV_SHIFT          (0u)
#define Sw_Clk_CMD_PA_DIV_SHIFT       (8u)
#define Sw_Clk_CMD_DISABLE_SHIFT      (30u)
#define Sw_Clk_CMD_ENABLE_SHIFT       (31u)

#define Sw_Clk_CMD_DISABLE_MASK       ((uint32)((uint32)1u << Sw_Clk_CMD_DISABLE_SHIFT))
#define Sw_Clk_CMD_ENABLE_MASK        ((uint32)((uint32)1u << Sw_Clk_CMD_ENABLE_SHIFT))

#define Sw_Clk_DIV_FRAC_MASK  (0x000000F8u)
#define Sw_Clk_DIV_FRAC_SHIFT (3u)
#define Sw_Clk_DIV_INT_MASK   (0xFFFFFF00u)
#define Sw_Clk_DIV_INT_SHIFT  (8u)

#else 

#define Sw_Clk_DIV_REG        (*(reg32 *)Sw_Clk__REGISTER)
#define Sw_Clk_ENABLE_REG     Sw_Clk_DIV_REG
#define Sw_Clk_DIV_FRAC_MASK  Sw_Clk__FRAC_MASK
#define Sw_Clk_DIV_FRAC_SHIFT (16u)
#define Sw_Clk_DIV_INT_MASK   Sw_Clk__DIVIDER_MASK
#define Sw_Clk_DIV_INT_SHIFT  (0u)

#endif/* CYREG_PERI_DIV_CMD */

#endif /* !defined(CY_CLOCK_Sw_Clk_H) */

/* [] END OF FILE */
