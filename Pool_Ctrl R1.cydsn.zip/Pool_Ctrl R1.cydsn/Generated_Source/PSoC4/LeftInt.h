/*******************************************************************************
* File Name: LeftInt.h
* Version 1.70
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/
#if !defined(CY_ISR_LeftInt_H)
#define CY_ISR_LeftInt_H


#include <cytypes.h>
#include <cyfitter.h>

/* Interrupt Controller API. */
void LeftInt_Start(void);
void LeftInt_StartEx(cyisraddress address);
void LeftInt_Stop(void);

CY_ISR_PROTO(LeftInt_Interrupt);

void LeftInt_SetVector(cyisraddress address);
cyisraddress LeftInt_GetVector(void);

void LeftInt_SetPriority(uint8 priority);
uint8 LeftInt_GetPriority(void);

void LeftInt_Enable(void);
uint8 LeftInt_GetState(void);
void LeftInt_Disable(void);

void LeftInt_SetPending(void);
void LeftInt_ClearPending(void);


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the LeftInt ISR. */
#define LeftInt_INTC_VECTOR            ((reg32 *) LeftInt__INTC_VECT)

/* Address of the LeftInt ISR priority. */
#define LeftInt_INTC_PRIOR             ((reg32 *) LeftInt__INTC_PRIOR_REG)

/* Priority of the LeftInt interrupt. */
#define LeftInt_INTC_PRIOR_NUMBER      LeftInt__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable LeftInt interrupt. */
#define LeftInt_INTC_SET_EN            ((reg32 *) LeftInt__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the LeftInt interrupt. */
#define LeftInt_INTC_CLR_EN            ((reg32 *) LeftInt__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the LeftInt interrupt state to pending. */
#define LeftInt_INTC_SET_PD            ((reg32 *) LeftInt__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the LeftInt interrupt. */
#define LeftInt_INTC_CLR_PD            ((reg32 *) LeftInt__INTC_CLR_PD_REG)



#endif /* CY_ISR_LeftInt_H */


/* [] END OF FILE */
