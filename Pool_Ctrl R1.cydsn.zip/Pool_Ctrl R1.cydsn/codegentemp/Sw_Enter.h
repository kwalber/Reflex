/*******************************************************************************
* File Name: Sw_Enter.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Sw_Enter_H) /* Pins Sw_Enter_H */
#define CY_PINS_Sw_Enter_H

#include "cytypes.h"
#include "cyfitter.h"
#include "Sw_Enter_aliases.h"


/***************************************
*     Data Struct Definitions
***************************************/

/**
* \addtogroup group_structures
* @{
*/
    
/* Structure for sleep mode support */
typedef struct
{
    uint32 pcState; /**< State of the port control register */
    uint32 sioState; /**< State of the SIO configuration */
    uint32 usbState; /**< State of the USBIO regulator */
} Sw_Enter_BACKUP_STRUCT;

/** @} structures */


/***************************************
*        Function Prototypes             
***************************************/
/**
* \addtogroup group_general
* @{
*/
uint8   Sw_Enter_Read(void);
void    Sw_Enter_Write(uint8 value);
uint8   Sw_Enter_ReadDataReg(void);
#if defined(Sw_Enter__PC) || (CY_PSOC4_4200L) 
    void    Sw_Enter_SetDriveMode(uint8 mode);
#endif
void    Sw_Enter_SetInterruptMode(uint16 position, uint16 mode);
uint8   Sw_Enter_ClearInterrupt(void);
/** @} general */

/**
* \addtogroup group_power
* @{
*/
void Sw_Enter_Sleep(void); 
void Sw_Enter_Wakeup(void);
/** @} power */


/***************************************
*           API Constants        
***************************************/
#if defined(Sw_Enter__PC) || (CY_PSOC4_4200L) 
    /* Drive Modes */
    #define Sw_Enter_DRIVE_MODE_BITS        (3)
    #define Sw_Enter_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - Sw_Enter_DRIVE_MODE_BITS))

    /**
    * \addtogroup group_constants
    * @{
    */
        /** \addtogroup driveMode Drive mode constants
         * \brief Constants to be passed as "mode" parameter in the Sw_Enter_SetDriveMode() function.
         *  @{
         */
        #define Sw_Enter_DM_ALG_HIZ         (0x00u) /**< \brief High Impedance Analog   */
        #define Sw_Enter_DM_DIG_HIZ         (0x01u) /**< \brief High Impedance Digital  */
        #define Sw_Enter_DM_RES_UP          (0x02u) /**< \brief Resistive Pull Up       */
        #define Sw_Enter_DM_RES_DWN         (0x03u) /**< \brief Resistive Pull Down     */
        #define Sw_Enter_DM_OD_LO           (0x04u) /**< \brief Open Drain, Drives Low  */
        #define Sw_Enter_DM_OD_HI           (0x05u) /**< \brief Open Drain, Drives High */
        #define Sw_Enter_DM_STRONG          (0x06u) /**< \brief Strong Drive            */
        #define Sw_Enter_DM_RES_UPDWN       (0x07u) /**< \brief Resistive Pull Up/Down  */
        /** @} driveMode */
    /** @} group_constants */
#endif

/* Digital Port Constants */
#define Sw_Enter_MASK               Sw_Enter__MASK
#define Sw_Enter_SHIFT              Sw_Enter__SHIFT
#define Sw_Enter_WIDTH              1u

/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Sw_Enter_SetInterruptMode() function.
     *  @{
     */
        #define Sw_Enter_INTR_NONE      ((uint16)(0x0000u)) /**< \brief Disabled             */
        #define Sw_Enter_INTR_RISING    ((uint16)(0x5555u)) /**< \brief Rising edge trigger  */
        #define Sw_Enter_INTR_FALLING   ((uint16)(0xaaaau)) /**< \brief Falling edge trigger */
        #define Sw_Enter_INTR_BOTH      ((uint16)(0xffffu)) /**< \brief Both edge trigger    */
    /** @} intrMode */
/** @} group_constants */

/* SIO LPM definition */
#if defined(Sw_Enter__SIO)
    #define Sw_Enter_SIO_LPM_MASK       (0x03u)
#endif

/* USBIO definitions */
#if !defined(Sw_Enter__PC) && (CY_PSOC4_4200L)
    #define Sw_Enter_USBIO_ENABLE               ((uint32)0x80000000u)
    #define Sw_Enter_USBIO_DISABLE              ((uint32)(~Sw_Enter_USBIO_ENABLE))
    #define Sw_Enter_USBIO_SUSPEND_SHIFT        CYFLD_USBDEVv2_USB_SUSPEND__OFFSET
    #define Sw_Enter_USBIO_SUSPEND_DEL_SHIFT    CYFLD_USBDEVv2_USB_SUSPEND_DEL__OFFSET
    #define Sw_Enter_USBIO_ENTER_SLEEP          ((uint32)((1u << Sw_Enter_USBIO_SUSPEND_SHIFT) \
                                                        | (1u << Sw_Enter_USBIO_SUSPEND_DEL_SHIFT)))
    #define Sw_Enter_USBIO_EXIT_SLEEP_PH1       ((uint32)~((uint32)(1u << Sw_Enter_USBIO_SUSPEND_SHIFT)))
    #define Sw_Enter_USBIO_EXIT_SLEEP_PH2       ((uint32)~((uint32)(1u << Sw_Enter_USBIO_SUSPEND_DEL_SHIFT)))
    #define Sw_Enter_USBIO_CR1_OFF              ((uint32)0xfffffffeu)
#endif


/***************************************
*             Registers        
***************************************/
/* Main Port Registers */
#if defined(Sw_Enter__PC)
    /* Port Configuration */
    #define Sw_Enter_PC                 (* (reg32 *) Sw_Enter__PC)
#endif
/* Pin State */
#define Sw_Enter_PS                     (* (reg32 *) Sw_Enter__PS)
/* Data Register */
#define Sw_Enter_DR                     (* (reg32 *) Sw_Enter__DR)
/* Input Buffer Disable Override */
#define Sw_Enter_INP_DIS                (* (reg32 *) Sw_Enter__PC2)

/* Interrupt configuration Registers */
#define Sw_Enter_INTCFG                 (* (reg32 *) Sw_Enter__INTCFG)
#define Sw_Enter_INTSTAT                (* (reg32 *) Sw_Enter__INTSTAT)

/* "Interrupt cause" register for Combined Port Interrupt (AllPortInt) in GSRef component */
#if defined (CYREG_GPIO_INTR_CAUSE)
    #define Sw_Enter_INTR_CAUSE         (* (reg32 *) CYREG_GPIO_INTR_CAUSE)
#endif

/* SIO register */
#if defined(Sw_Enter__SIO)
    #define Sw_Enter_SIO_REG            (* (reg32 *) Sw_Enter__SIO)
#endif /* (Sw_Enter__SIO_CFG) */

/* USBIO registers */
#if !defined(Sw_Enter__PC) && (CY_PSOC4_4200L)
    #define Sw_Enter_USB_POWER_REG       (* (reg32 *) CYREG_USBDEVv2_USB_POWER_CTRL)
    #define Sw_Enter_CR1_REG             (* (reg32 *) CYREG_USBDEVv2_CR1)
    #define Sw_Enter_USBIO_CTRL_REG      (* (reg32 *) CYREG_USBDEVv2_USB_USBIO_CTRL)
#endif    
    
    
/***************************************
* The following code is DEPRECATED and 
* must not be used in new designs.
***************************************/
/**
* \addtogroup group_deprecated
* @{
*/
#define Sw_Enter_DRIVE_MODE_SHIFT       (0x00u)
#define Sw_Enter_DRIVE_MODE_MASK        (0x07u << Sw_Enter_DRIVE_MODE_SHIFT)
/** @} deprecated */

#endif /* End Pins Sw_Enter_H */


/* [] END OF FILE */
