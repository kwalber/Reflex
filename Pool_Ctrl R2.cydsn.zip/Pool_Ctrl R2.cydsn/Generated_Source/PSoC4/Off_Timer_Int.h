/*******************************************************************************
* File Name: Off_Timer_Int.h
* Version 1.70
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/
#if !defined(CY_ISR_Off_Timer_Int_H)
#define CY_ISR_Off_Timer_Int_H


#include <cytypes.h>
#include <cyfitter.h>

/* Interrupt Controller API. */
void Off_Timer_Int_Start(void);
void Off_Timer_Int_StartEx(cyisraddress address);
void Off_Timer_Int_Stop(void);

CY_ISR_PROTO(Off_Timer_Int_Interrupt);

void Off_Timer_Int_SetVector(cyisraddress address);
cyisraddress Off_Timer_Int_GetVector(void);

void Off_Timer_Int_SetPriority(uint8 priority);
uint8 Off_Timer_Int_GetPriority(void);

void Off_Timer_Int_Enable(void);
uint8 Off_Timer_Int_GetState(void);
void Off_Timer_Int_Disable(void);

void Off_Timer_Int_SetPending(void);
void Off_Timer_Int_ClearPending(void);


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the Off_Timer_Int ISR. */
#define Off_Timer_Int_INTC_VECTOR            ((reg32 *) Off_Timer_Int__INTC_VECT)

/* Address of the Off_Timer_Int ISR priority. */
#define Off_Timer_Int_INTC_PRIOR             ((reg32 *) Off_Timer_Int__INTC_PRIOR_REG)

/* Priority of the Off_Timer_Int interrupt. */
#define Off_Timer_Int_INTC_PRIOR_NUMBER      Off_Timer_Int__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable Off_Timer_Int interrupt. */
#define Off_Timer_Int_INTC_SET_EN            ((reg32 *) Off_Timer_Int__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the Off_Timer_Int interrupt. */
#define Off_Timer_Int_INTC_CLR_EN            ((reg32 *) Off_Timer_Int__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the Off_Timer_Int interrupt state to pending. */
#define Off_Timer_Int_INTC_SET_PD            ((reg32 *) Off_Timer_Int__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the Off_Timer_Int interrupt. */
#define Off_Timer_Int_INTC_CLR_PD            ((reg32 *) Off_Timer_Int__INTC_CLR_PD_REG)



#endif /* CY_ISR_Off_Timer_Int_H */


/* [] END OF FILE */
