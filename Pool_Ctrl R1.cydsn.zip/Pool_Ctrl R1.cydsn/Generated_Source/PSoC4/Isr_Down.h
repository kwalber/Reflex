/*******************************************************************************
* File Name: Isr_Down.h
* Version 1.70
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/
#if !defined(CY_ISR_Isr_Down_H)
#define CY_ISR_Isr_Down_H


#include <cytypes.h>
#include <cyfitter.h>

/* Interrupt Controller API. */
void Isr_Down_Start(void);
void Isr_Down_StartEx(cyisraddress address);
void Isr_Down_Stop(void);

CY_ISR_PROTO(Isr_Down_Interrupt);

void Isr_Down_SetVector(cyisraddress address);
cyisraddress Isr_Down_GetVector(void);

void Isr_Down_SetPriority(uint8 priority);
uint8 Isr_Down_GetPriority(void);

void Isr_Down_Enable(void);
uint8 Isr_Down_GetState(void);
void Isr_Down_Disable(void);

void Isr_Down_SetPending(void);
void Isr_Down_ClearPending(void);


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the Isr_Down ISR. */
#define Isr_Down_INTC_VECTOR            ((reg32 *) Isr_Down__INTC_VECT)

/* Address of the Isr_Down ISR priority. */
#define Isr_Down_INTC_PRIOR             ((reg32 *) Isr_Down__INTC_PRIOR_REG)

/* Priority of the Isr_Down interrupt. */
#define Isr_Down_INTC_PRIOR_NUMBER      Isr_Down__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable Isr_Down interrupt. */
#define Isr_Down_INTC_SET_EN            ((reg32 *) Isr_Down__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the Isr_Down interrupt. */
#define Isr_Down_INTC_CLR_EN            ((reg32 *) Isr_Down__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the Isr_Down interrupt state to pending. */
#define Isr_Down_INTC_SET_PD            ((reg32 *) Isr_Down__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the Isr_Down interrupt. */
#define Isr_Down_INTC_CLR_PD            ((reg32 *) Isr_Down__INTC_CLR_PD_REG)



#endif /* CY_ISR_Isr_Down_H */


/* [] END OF FILE */
