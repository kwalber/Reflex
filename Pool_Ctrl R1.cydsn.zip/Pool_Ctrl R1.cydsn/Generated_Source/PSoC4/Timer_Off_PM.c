/*******************************************************************************
* File Name: Timer_Off_PM.c
* Version 2.70
*
*  Description:
*     This file provides the power management source code to API for the
*     Timer.
*
*   Note:
*     None
*
*******************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
********************************************************************************/

#include "Timer_Off.h"

static Timer_Off_backupStruct Timer_Off_backup;


/*******************************************************************************
* Function Name: Timer_Off_SaveConfig
********************************************************************************
*
* Summary:
*     Save the current user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Timer_Off_backup:  Variables of this global structure are modified to
*  store the values of non retention configuration registers when Sleep() API is
*  called.
*
*******************************************************************************/
void Timer_Off_SaveConfig(void) 
{
    #if (!Timer_Off_UsingFixedFunction)
        Timer_Off_backup.TimerUdb = Timer_Off_ReadCounter();
        Timer_Off_backup.InterruptMaskValue = Timer_Off_STATUS_MASK;
        #if (Timer_Off_UsingHWCaptureCounter)
            Timer_Off_backup.TimerCaptureCounter = Timer_Off_ReadCaptureCount();
        #endif /* Back Up capture counter register  */

        #if(!Timer_Off_UDB_CONTROL_REG_REMOVED)
            Timer_Off_backup.TimerControlRegister = Timer_Off_ReadControlRegister();
        #endif /* Backup the enable state of the Timer component */
    #endif /* Backup non retention registers in UDB implementation. All fixed function registers are retention */
}


/*******************************************************************************
* Function Name: Timer_Off_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Timer_Off_backup:  Variables of this global structure are used to
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void Timer_Off_RestoreConfig(void) 
{   
    #if (!Timer_Off_UsingFixedFunction)

        Timer_Off_WriteCounter(Timer_Off_backup.TimerUdb);
        Timer_Off_STATUS_MASK =Timer_Off_backup.InterruptMaskValue;
        #if (Timer_Off_UsingHWCaptureCounter)
            Timer_Off_SetCaptureCount(Timer_Off_backup.TimerCaptureCounter);
        #endif /* Restore Capture counter register*/

        #if(!Timer_Off_UDB_CONTROL_REG_REMOVED)
            Timer_Off_WriteControlRegister(Timer_Off_backup.TimerControlRegister);
        #endif /* Restore the enable state of the Timer component */
    #endif /* Restore non retention registers in the UDB implementation only */
}


/*******************************************************************************
* Function Name: Timer_Off_Sleep
********************************************************************************
*
* Summary:
*     Stop and Save the user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Timer_Off_backup.TimerEnableState:  Is modified depending on the
*  enable state of the block before entering sleep mode.
*
*******************************************************************************/
void Timer_Off_Sleep(void) 
{
    #if(!Timer_Off_UDB_CONTROL_REG_REMOVED)
        /* Save Counter's enable state */
        if(Timer_Off_CTRL_ENABLE == (Timer_Off_CONTROL & Timer_Off_CTRL_ENABLE))
        {
            /* Timer is enabled */
            Timer_Off_backup.TimerEnableState = 1u;
        }
        else
        {
            /* Timer is disabled */
            Timer_Off_backup.TimerEnableState = 0u;
        }
    #endif /* Back up enable state from the Timer control register */
    Timer_Off_Stop();
    Timer_Off_SaveConfig();
}


/*******************************************************************************
* Function Name: Timer_Off_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Timer_Off_backup.enableState:  Is used to restore the enable state of
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void Timer_Off_Wakeup(void) 
{
    Timer_Off_RestoreConfig();
    #if(!Timer_Off_UDB_CONTROL_REG_REMOVED)
        if(Timer_Off_backup.TimerEnableState == 1u)
        {     /* Enable Timer's operation */
                Timer_Off_Enable();
        } /* Do nothing if Timer was disabled before */
    #endif /* Remove this code section if Control register is removed */
}


/* [] END OF FILE */
