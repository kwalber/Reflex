/*******************************************************************************
* File Name: Sw_Right.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Sw_Right_H) /* Pins Sw_Right_H */
#define CY_PINS_Sw_Right_H

#include "cytypes.h"
#include "cyfitter.h"
#include "Sw_Right_aliases.h"


/***************************************
*     Data Struct Definitions
***************************************/

/**
* \addtogroup group_structures
* @{
*/
    
/* Structure for sleep mode support */
typedef struct
{
    uint32 pcState; /**< State of the port control register */
    uint32 sioState; /**< State of the SIO configuration */
    uint32 usbState; /**< State of the USBIO regulator */
} Sw_Right_BACKUP_STRUCT;

/** @} structures */


/***************************************
*        Function Prototypes             
***************************************/
/**
* \addtogroup group_general
* @{
*/
uint8   Sw_Right_Read(void);
void    Sw_Right_Write(uint8 value);
uint8   Sw_Right_ReadDataReg(void);
#if defined(Sw_Right__PC) || (CY_PSOC4_4200L) 
    void    Sw_Right_SetDriveMode(uint8 mode);
#endif
void    Sw_Right_SetInterruptMode(uint16 position, uint16 mode);
uint8   Sw_Right_ClearInterrupt(void);
/** @} general */

/**
* \addtogroup group_power
* @{
*/
void Sw_Right_Sleep(void); 
void Sw_Right_Wakeup(void);
/** @} power */


/***************************************
*           API Constants        
***************************************/
#if defined(Sw_Right__PC) || (CY_PSOC4_4200L) 
    /* Drive Modes */
    #define Sw_Right_DRIVE_MODE_BITS        (3)
    #define Sw_Right_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - Sw_Right_DRIVE_MODE_BITS))

    /**
    * \addtogroup group_constants
    * @{
    */
        /** \addtogroup driveMode Drive mode constants
         * \brief Constants to be passed as "mode" parameter in the Sw_Right_SetDriveMode() function.
         *  @{
         */
        #define Sw_Right_DM_ALG_HIZ         (0x00u) /**< \brief High Impedance Analog   */
        #define Sw_Right_DM_DIG_HIZ         (0x01u) /**< \brief High Impedance Digital  */
        #define Sw_Right_DM_RES_UP          (0x02u) /**< \brief Resistive Pull Up       */
        #define Sw_Right_DM_RES_DWN         (0x03u) /**< \brief Resistive Pull Down     */
        #define Sw_Right_DM_OD_LO           (0x04u) /**< \brief Open Drain, Drives Low  */
        #define Sw_Right_DM_OD_HI           (0x05u) /**< \brief Open Drain, Drives High */
        #define Sw_Right_DM_STRONG          (0x06u) /**< \brief Strong Drive            */
        #define Sw_Right_DM_RES_UPDWN       (0x07u) /**< \brief Resistive Pull Up/Down  */
        /** @} driveMode */
    /** @} group_constants */
#endif

/* Digital Port Constants */
#define Sw_Right_MASK               Sw_Right__MASK
#define Sw_Right_SHIFT              Sw_Right__SHIFT
#define Sw_Right_WIDTH              1u

/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Sw_Right_SetInterruptMode() function.
     *  @{
     */
        #define Sw_Right_INTR_NONE      ((uint16)(0x0000u)) /**< \brief Disabled             */
        #define Sw_Right_INTR_RISING    ((uint16)(0x5555u)) /**< \brief Rising edge trigger  */
        #define Sw_Right_INTR_FALLING   ((uint16)(0xaaaau)) /**< \brief Falling edge trigger */
        #define Sw_Right_INTR_BOTH      ((uint16)(0xffffu)) /**< \brief Both edge trigger    */
    /** @} intrMode */
/** @} group_constants */

/* SIO LPM definition */
#if defined(Sw_Right__SIO)
    #define Sw_Right_SIO_LPM_MASK       (0x03u)
#endif

/* USBIO definitions */
#if !defined(Sw_Right__PC) && (CY_PSOC4_4200L)
    #define Sw_Right_USBIO_ENABLE               ((uint32)0x80000000u)
    #define Sw_Right_USBIO_DISABLE              ((uint32)(~Sw_Right_USBIO_ENABLE))
    #define Sw_Right_USBIO_SUSPEND_SHIFT        CYFLD_USBDEVv2_USB_SUSPEND__OFFSET
    #define Sw_Right_USBIO_SUSPEND_DEL_SHIFT    CYFLD_USBDEVv2_USB_SUSPEND_DEL__OFFSET
    #define Sw_Right_USBIO_ENTER_SLEEP          ((uint32)((1u << Sw_Right_USBIO_SUSPEND_SHIFT) \
                                                        | (1u << Sw_Right_USBIO_SUSPEND_DEL_SHIFT)))
    #define Sw_Right_USBIO_EXIT_SLEEP_PH1       ((uint32)~((uint32)(1u << Sw_Right_USBIO_SUSPEND_SHIFT)))
    #define Sw_Right_USBIO_EXIT_SLEEP_PH2       ((uint32)~((uint32)(1u << Sw_Right_USBIO_SUSPEND_DEL_SHIFT)))
    #define Sw_Right_USBIO_CR1_OFF              ((uint32)0xfffffffeu)
#endif


/***************************************
*             Registers        
***************************************/
/* Main Port Registers */
#if defined(Sw_Right__PC)
    /* Port Configuration */
    #define Sw_Right_PC                 (* (reg32 *) Sw_Right__PC)
#endif
/* Pin State */
#define Sw_Right_PS                     (* (reg32 *) Sw_Right__PS)
/* Data Register */
#define Sw_Right_DR                     (* (reg32 *) Sw_Right__DR)
/* Input Buffer Disable Override */
#define Sw_Right_INP_DIS                (* (reg32 *) Sw_Right__PC2)

/* Interrupt configuration Registers */
#define Sw_Right_INTCFG                 (* (reg32 *) Sw_Right__INTCFG)
#define Sw_Right_INTSTAT                (* (reg32 *) Sw_Right__INTSTAT)

/* "Interrupt cause" register for Combined Port Interrupt (AllPortInt) in GSRef component */
#if defined (CYREG_GPIO_INTR_CAUSE)
    #define Sw_Right_INTR_CAUSE         (* (reg32 *) CYREG_GPIO_INTR_CAUSE)
#endif

/* SIO register */
#if defined(Sw_Right__SIO)
    #define Sw_Right_SIO_REG            (* (reg32 *) Sw_Right__SIO)
#endif /* (Sw_Right__SIO_CFG) */

/* USBIO registers */
#if !defined(Sw_Right__PC) && (CY_PSOC4_4200L)
    #define Sw_Right_USB_POWER_REG       (* (reg32 *) CYREG_USBDEVv2_USB_POWER_CTRL)
    #define Sw_Right_CR1_REG             (* (reg32 *) CYREG_USBDEVv2_CR1)
    #define Sw_Right_USBIO_CTRL_REG      (* (reg32 *) CYREG_USBDEVv2_USB_USBIO_CTRL)
#endif    
    
    
/***************************************
* The following code is DEPRECATED and 
* must not be used in new designs.
***************************************/
/**
* \addtogroup group_deprecated
* @{
*/
#define Sw_Right_DRIVE_MODE_SHIFT       (0x00u)
#define Sw_Right_DRIVE_MODE_MASK        (0x07u << Sw_Right_DRIVE_MODE_SHIFT)
/** @} deprecated */

#endif /* End Pins Sw_Right_H */


/* [] END OF FILE */
